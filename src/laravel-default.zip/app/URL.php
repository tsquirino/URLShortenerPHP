<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class URL extends Model {

    protected $table = 'URL';
    public $timestamps = false;

}
