<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>URLShortener - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="css/app.css">
</head>
<body>
    <!-- Page container-->
    <div class="container">

        <!-- Header -->
        <div class="page-header">
            <h1><?php echo $__env->yieldContent('header'); ?></h1>
        </div>

        <!-- Display flashed messages-->
        <?php if(isset($messages) && count($messages) > 0): ?>
        <ul class="list-unstyled">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="alert alert-success"><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

        <!-- Page contents -->
        <?php echo $__env->yieldContent('content'); ?>

    </div>
</body>
</html>