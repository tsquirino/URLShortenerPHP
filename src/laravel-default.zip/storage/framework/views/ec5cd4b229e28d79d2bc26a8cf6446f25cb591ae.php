
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('header', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('login_post')); ?>">
    <?php echo csrf_field(); ?>

    
    <p>
        <label>Username:</label>
        <input class="form-control" type="text" name="username" />
    </p>
    <p>
        <label>Password:</label>
        <input class="form-control" type="password" name="password" />
    </p>
    <p>
        <button class="btn btn-primary" type="submit">Sign in</button>
    </p>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>