
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('header', 'URLShortener'); ?>

<?php $__env->startSection('content'); ?>

<p class="pull-right">
    <a href="<?php echo e(route('logout')); ?>">Logout</a>
</p>

<!-- List of URLs -->
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Shortened URL</th>
            <th scope="col">Original URL</th>
            <th scope="col">Expiration date</th>
        </tr>
    </thead>
    <tbody>
    <?php if(isset($urls)): ?>
    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($url['id']); ?></th>
      <td><a href="<?php echo e($url['shortened_url']); ?>" target="_blank"><?php echo e($url['shortened_url']); ?></a></td>
      <td><a href="<?php echo e($url['original_url']); ?>" target="_blank"><?php echo e($url['original_url']); ?></a></td>
      <td><?php echo e($url['expiration_date']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
      <th scope="row" colspan="0">No URLs found.</th>
    </tr>
    <?php endif; ?>
    </tbody>
</table>

<!-- Pagination links -->
<?php if(isset($pagination)): ?>
<div class="text-center">
  <ul class="pagination">
    <?php if($pagination['current'] > 1): ?>
    <li class="page-item">
      <a class="page-link" href="<?php echo e($pagination['_links']['first']); ?>">&lt;&lt;</a>
    </li>
    <?php else: ?>
    <li class="page-item disabled">
      <a class="page-link" href="#">&lt;&lt;</a>
    </li>
    <?php endif; ?>
    <?php if($pagination['current'] > 1): ?>
    <li class="page-item">
        <a class="page-link" href="<?php echo e($pagination['_links']['prev']); ?>">&lt;</a>
    </li>
    <?php else: ?>
    <li class="page-item disabled">
        <a class="page-link" href="#">&lt;</a>
    </li>
    <?php endif; ?>
    <li class="page-item active">
      <a class="page-link" href="#"><?php echo e($pagination['current']); ?> <span class="sr-only">/<?php echo e($pagination['total']); ?></span></a>
    </li>
    <?php if($pagination['current'] < $pagination['total']): ?>
    <li class="page-item">
        <a class="page-link" href="<?php echo e($pagination['_links']['next']); ?>">&gt;</a>
    </li>
    <?php else: ?>
    <li class="page-item disabled">
        <a class="page-link" href="#">&gt;</a>
    </li>
    <?php endif; ?>
    <?php if($pagination['current'] < $pagination['total']): ?>
    <li class="page-item">
      <a class="page-link" href="<?php echo e($pagination['_links']['last']); ?>">&gt;&gt;</a>
    </li>
    <?php else: ?>
    <li class="page-item disabled">
        <a class="page-link" href="#">&gt;&gt;</a>
    </li>
    <?php endif; ?>
  </ul>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>